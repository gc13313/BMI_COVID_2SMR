#######################################################################
#         TWO SAMPLE MR                                               #
#######################################################################
# R version 4.0.2 

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)

#ao <- available_outcomes()

#---------------------------------------------------------------------#
#                         All results                                 #----
#---------------------------------------------------------------------#
#append results
#B1
results_B1_b_v3 <- read.xlsx(xlsxFile = "results_B1_b_v3.xlsx")
results_B1_b_v3$version <- "Release 3"
results_B1_b_v4 <- read.xlsx(xlsxFile = "results_B1_b_v4.xlsx")
results_B1_b_v4$version <- "Release 4"
results_B1_b_v5 <- read.xlsx(xlsxFile = "results_B1_b_v5.xlsx")
results_B1_b_v5$version <- "Release 5"
results_B1_b_v6 <- read.xlsx(xlsxFile = "results_B1_b_v6.xlsx")
results_B1_b_v6$version <- "Release 6"
#C2
results_C2_b_v3 <- read.xlsx(xlsxFile = "results_C2_b_v3.xlsx")
results_C2_b_v3$version <- "Release 3"
results_C2_b_v4 <- read.xlsx(xlsxFile = "results_C2_b_v4.xlsx")
results_C2_b_v4$version <- "Release 4"
results_C2_b_v5 <- read.xlsx(xlsxFile = "results_C2_b_v5.xlsx")
results_C2_b_v5$version <- "Release 5"
results_C2_b_v6 <- read.xlsx(xlsxFile = "results_C2_b_v6.xlsx")
results_C2_b_v6$version <- "Release 6"

results <- as.data.frame(rbind(results_B1_b_v3, results_B1_b_v4, results_B1_b_v5, results_B1_b_v6, results_C2_b_v3, results_C2_b_v4, results_C2_b_v5, results_C2_b_v6))

results<-subset(results, method!="Weighted mode")
results<-subset(results, method!="Maximum likelihood")
results<-subset(results, method!="Unweighted regression")
results<-subset(results, method!="MR Egger")
results<-subset(results, method!="Weighted median")

#rename variables so theyre nicer
results$exposure[results$exposure=="body mass index || id:ieu-b-40"] <- 'BMI'
results$method[results$method=="Inverse variance weighted"] <- 'IVW'
results$var  = paste(results$outcome, results$version, sep="-")

# Reorder outcomes as factors
as.factor(results$outcome)

a <- metagen(TE = b, seTE = se, data = results, 
             studlab = paste(version), sm = "OR",
             hakn = FALSE, byvar=outcome, comb.fixed = F, comb.random=F)


print(a)

#forest plot
forest_results_b<-forest.meta(a, studlab = T, 
                          type.study="square",
                          squaresize=0.7,
                          lty.random = 3,
                          bylab = " ",
                          text.random = "Total", # write anything 
                          text.random.w = "Total",
                          col.study = c("deepskyblue",
                                        "deepskyblue", 
                                        "deepskyblue", 
                                        "deepskyblue", 
                                        "deepskyblue", 
                                        "deepskyblue", 
                                        "deepskyblue",
                                        "deepskyblue") , 
                          col.square = c("deepskyblue",
                                         "deepskyblue", 
                                         "deepskyblue", 
                                         "deepskyblue", 
                                         "deepskyblue", 
                                         "deepskyblue", 
                                         "deepskyblue",
                                         "deepskyblue") , 
                          col.diamond="white", 
                          col.diamond.lines="black",
                          col.label.right="black",
                          col.label.left="black", 
                          colgap.right = "0.5cm",
                          colgap.forest.left ="0.5cm",
                          col.by = "black",
                          xlab="OR per SD increase in BMI", 
                          leftcols=c("studlab", "nsnp", "cases", "controls"),# To remove "logHR" and "seHR" from plot
                          leftlabs = c("Outcome", "SNPs", "Cases", "Controls"),
                          rightcols=c("effect", "ci", "Q_pval"),
                          rightlabs=c("OR","[95% CI]","p-het"),
                          test.overall = F,
                          lwd=2,
                          print.I2 = a$comb.fixed,
                          plotwidth="10.5cm",
                          print.I2.ci = FALSE, 
                          print.tau2 = F, 
                          print.Q = FALSE,
                          print.subgroup.name=F,
                          byseparator = "",
                          print.byvar=F,
                          digits.mean = 2,
                          digits.addcols.right = 3,
                          fontsize = 12,
                          overall = FALSE,
                          overall.hetstat = FALSE,
                          test.subgroup.fixed=FALSE,
                          fixed=F,
                          smlab="",
                          spacing = 2, at = c(0.5, 0.75, 1, 1.5, 2))

forest_results_b <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=3200, width=3500)
  print(plot_name)
  dev.off()
}

#setwd
setwd("")


save_func("forest_BMItocovid_time_IVW_4a.png", forest_results_b)


