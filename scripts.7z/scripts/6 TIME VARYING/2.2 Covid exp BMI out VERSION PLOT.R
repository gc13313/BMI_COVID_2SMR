#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)

#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#

##LOAD DATA
results_all_c <- read.xlsx(xlsxFile = "covid_exp_results_all_V.xlsx")


results_all_c$method[results_all_c$method=="Inverse variance weighted"] <- 'IVW'
results_all_c$method[results_all_c$method=="Wald ratio"] <- 'IVW'

#results_all_ivw$var  = paste(results_all_ivw$exposure, results_all_ivw$method, sep="-")





a <- metagen(TE = b, seTE = se, data = results_all_c, 
             studlab = paste(version), sm = "MD",
             hakn = FALSE, subgroup = exposure, fixed = F, random=F)


print(a)

#forest plot
forest_results_c <-forest.meta(a, studlab = T, 
                                          type.study="square",
                                          squaresize=0.5,
                                          lty.random = 2,
                                          bylab = " ",
                                          text.random = "Total", # write anything 
                                          text.random.w = "Total",
                                          col.study = c("deepskyblue", 
                                                        "deepskyblue",
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue") ,    
                                          col.square = c("deepskyblue", 
                                                         "deepskyblue",
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue") , 
                                          col.diamond="white", 
                                          col.diamond.lines="black",
                                          col.label.right="black",
                                          col.label.left="black", 
                                          colgap.right = "0.5cm",
                                          colgap.forest.left ="0.5cm",
                                          col.by = "black",
                                          title="",
                                          smlab="",
                                          xlab="Difference in mean BMI", 
                                          leftcols=c("studlab", "nsnp"),# To remove "logHR" and "seHR" from plot
                                          leftlabs = c("Outcome", "SNPs"),
                                          rightcols=c("effect", "ci"),
                                          rightlabs=c("MD","[95% CI]"),
                                          test.overall = F,
                                          lwd=3,
                                          print.I2 = a$comb.fixed,
                                          plotwidth="10.5cm",
                                          print.I2.ci = FALSE, 
                                          print.tau2 = F, 
                                          print.Q = FALSE,
                                          print.subgroup.name=F,
                                          digits.mean = 4,
                                          digits = 3,
                                          digits.addcols.right = 3,
                                          fontsize = 12,
                                          overall = FALSE,
                                          overall.hetstat = FALSE,
                                          test.subgroup.fixed=FALSE,
                                          fixed=F,
                                          spacing = 2)
forest_results_c <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=2600, width=3300)
  print(plot_name)
  dev.off()
}


save_func("forest_covid_exp_version_4b.png", forest_results_c)





