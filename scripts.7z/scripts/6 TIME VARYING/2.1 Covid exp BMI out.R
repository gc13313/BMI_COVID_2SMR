#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: covid
# Outcome: BMI

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#

#setwd
setwd("")


exposure_dat_B1_V3 <- read.xlsx(xlsxFile = "exposure_dat_B1_V3.xlsx")
exposure_dat_B1_V3$version <- "Release 3"
exposure_dat_B1_V4 <- read.xlsx(xlsxFile = "exposure_dat_B1_V4.xlsx")
exposure_dat_B1_V4$version <- "Release 4"
exposure_dat_B1_V5 <- read.xlsx(xlsxFile = "exposure_dat_B1_V5.xlsx")
exposure_dat_B1_V5$version <- "Release 5"
exposure_dat_B1_V6 <- read.xlsx(xlsxFile = "exposure_dat_B1_V6.xlsx")
exposure_dat_B1_V6$version <- "Release 6"

exposure_dat_C2_V3 <- read.xlsx(xlsxFile = "exposure_dat_C2_V3.xlsx")
exposure_dat_C2_V3$version <- "Release 3"
exposure_dat_C2_V4 <- read.xlsx(xlsxFile = "exposure_dat_C2_V4.xlsx")
exposure_dat_C2_V4$version <- "Release 4"
exposure_dat_C2_V5 <- read.xlsx(xlsxFile = "exposure_dat_C2_V5.xlsx")
exposure_dat_C2_V5$version <- "Release 5"
exposure_dat_C2_V6 <- read.xlsx(xlsxFile = "exposure_dat_C2_V6.xlsx")
exposure_dat_C2_V6$version <- "Release 6"

#---------------------------------------------------------------------#
#                          Combine exposures                          #
#---------------------------------------------------------------------#

#Should have the following cols:
head(exposure_dat_C2_V3)
#other_allele.exposure 
#effect_allele.exposure 
#beta.exposure 
#se.exposure 
#pval.exposure 
#eaf.exposure
#SNP 
#samplesize.exposure                           
#exposure 
#id.exposure

#Need to have all same cols
exposure_dat_B1_V3 <- subset(exposure_dat_B1_V3, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_B1_V4 <- subset(exposure_dat_B1_V4, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_B1_V5 <- subset(exposure_dat_B1_V5, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_B1_V6 <- subset(exposure_dat_B1_V6, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_C2_V3 <- subset(exposure_dat_C2_V3, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_C2_V4 <- subset(exposure_dat_C2_V4, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_C2_V5 <- subset(exposure_dat_C2_V5, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))
exposure_dat_C2_V6 <- subset(exposure_dat_C2_V6, select = c(other_allele.exposure, effect_allele.exposure, beta.exposure, se.exposure, pval.exposure, eaf.exposure, SNP, id.exposure, exposure))




#exposure_dat <- as.data.frame(rbind(exposure_dat_B1_V3, exposure_dat_B1_V4, exposure_dat_B1, exposure_dat_B2, exposure_dat_C1, exposure_dat_C2, exposure_dat_D1))
#exposure_dat$mr_keep.exposure<-"TRUE"
#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#BMI
BMI_B1_V3 <- extract_outcome_data(snps=exposure_dat_B1_V3$SNP, outcomes="ieu-b-40", proxies=T)
BMI_B1_V4 <- extract_outcome_data(snps=exposure_dat_B1_V4$SNP, outcomes="ieu-b-40", proxies=T)
BMI_B1_V5 <- extract_outcome_data(snps=exposure_dat_B1_V5$SNP, outcomes="ieu-b-40", proxies=T)
BMI_B1_V6 <- extract_outcome_data(snps=exposure_dat_B1_V6$SNP, outcomes="ieu-b-40", proxies=T)


BMI_C2_V3 <- extract_outcome_data(snps=exposure_dat_C2_V3$SNP, outcomes="ieu-b-40", proxies=T)
BMI_C2_V4 <- extract_outcome_data(snps=exposure_dat_C2_V4$SNP, outcomes="ieu-b-40", proxies=T)
BMI_C2_V5 <- extract_outcome_data(snps=exposure_dat_C2_V5$SNP, outcomes="ieu-b-40", proxies=T)
BMI_C2_V6 <- extract_outcome_data(snps=exposure_dat_C2_V6$SNP, outcomes="ieu-b-40", proxies=T)



#BMI <- extract_outcome_data(snps=exposure_dat_A2$SNP, outcomes="ieu-b-40")
#out_dat_c <- as.data.frame(rbind(BMI))
#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_B1_V3_c <- harmonise_data(exposure_dat = exposure_dat_B1_V3, outcome_dat = BMI_B1_V3, action=2)
data_B1_V4_c <- harmonise_data(exposure_dat = exposure_dat_B1_V4, outcome_dat = BMI_B1_V4, action=2)
data_B1_V5_c <- harmonise_data(exposure_dat = exposure_dat_B1_V5, outcome_dat = BMI_B1_V5, action=2)
data_B1_V6_c <- harmonise_data(exposure_dat = exposure_dat_B1_V6, outcome_dat = BMI_B1_V6, action=2)

#data_C2_V3_c <- harmonise_data(exposure_dat = exposure_dat_C2_V3, outcome_dat = BMI_C2_V3, action=2)
#null
data_C2_V4_c <- harmonise_data(exposure_dat = exposure_dat_C2_V4, outcome_dat = BMI_C2_V4, action=2)
data_C2_V5_c <- harmonise_data(exposure_dat = exposure_dat_C2_V5, outcome_dat = BMI_C2_V5, action=2)
data_C2_V6_c <- harmonise_data(exposure_dat = exposure_dat_C2_V6, outcome_dat = BMI_C2_V6, action=2)


data_B1_c <- as.data.frame(rbind(data_B1_V3_c, data_B1_V4_c, data_B1_V5_c, data_B1_V6_c))
data_C2_c <- as.data.frame(rbind(data_C2_V4_c, data_C2_V5_c, data_C2_V6_c))

#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
mr_method_list()

results_B1_V3_c <- mr(data_B1_V3_c, method_list = c("mr_ivw"))
results_B1_V3_c$version<-"Release 3"
results_B1_V4_c <- mr(data_B1_V4_c, method_list = c("mr_ivw"))
results_B1_V4_c$version<-"Release 4"
results_B1_V5_c <- mr(data_B1_V5_c, method_list = c("mr_ivw"))
results_B1_V5_c$version<-"Release 5"
results_B1_V6_c <- mr(data_B1_V6_c, method_list = c("mr_ivw"))
results_B1_V6_c$version<-"Release 6"

results_C2_V4_c <- mr(data_C2_V4_c, method_list = c("mr_wald_ratio"))
results_C2_V4_c$version<-"Release 4"
results_C2_V5_c <- mr(data_C2_V5_c, method_list = c("mr_ivw"))
results_C2_V5_c$version<-"Release 5"
results_C2_V6_c <- mr(data_C2_V6_c, method_list = c("mr_ivw"))
results_C2_V6_c$version<-"Release 6"

results_all_B1_V <- as.data.frame(rbind(results_B1_V3_c, results_B1_V4_c, results_B1_V5_c, results_B1_V6_c))
results_all_C2_V <- as.data.frame(rbind(results_C2_V4_c, results_C2_V5_c, results_C2_V6_c))

results_all_V <- as.data.frame(rbind(results_all_B1_V, results_all_C2_V))


write.xlsx(results_all_V, file = "covid_exp_results_all_V.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "covid_exp_results_all_V.xlsx")

###############################################################################
plt_c <- mr_pleiotropy_test(data_all_c)
het_c <- mr_heterogeneity(data_all_c)

write.xlsx(plt_c, file = "plt_v.xlsx", overwrite=T)
plt_c <- read.xlsx(xlsxFile = "plt_v.xlsx")

write.xlsx(het_c, file = "het_v.xlsx", overwrite=T)
het_c <- read.xlsx(xlsxFile = "het_v.xlsx")

#MERGE pleitropy and results - binary
#1 add p-egger intercept to egger res
plt_c <- read.xlsx(xlsxFile = "plt_v.xlsx")
#want to merge this with mr egger
p_egger_c<-select(plt_c , id.exposure, id.outcome, pval)

names(p_egger_c)[names(p_egger_c) == 'pval'] <- 'p_egger'
results_egger_c<-subset(results_all_c, method=="MR Egger")



results_egger_c_plt <- merge(results_egger_c,p_egger_c ,by=c("id.outcome","id.exposure"), all=F)
p_egger_tomerge_c<-select(results_egger_c_plt , id.exposure, id.outcome, p_egger, method)

#2 add p-q for ivw hetero 
het_c <- read.xlsx(xlsxFile = "het_v.xlsx")
p_het_c<-select(het_c , id.exposure, id.outcome, method, Q_pval)
p_het_c<-subset(p_het_c, method=="Inverse variance weighted")
results_ivw_c<-subset(results_all_c, method=="Inverse variance weighted")

#now want to merge back into results_all_b
results_all_c1<- merge(p_egger_tomerge_c,results_all_c ,by=c("id.outcome","id.exposure", "method"), all=T)
results_all_c<-results_all_c1
results_all_c2<-merge(p_het_c,results_all_c ,by=c("id.outcome","id.exposure", "method"), all=T)
results_all_c<-results_all_c2


write.xlsx(results_all_c, file = "results_all_v.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "results_all_v.xlsx")

