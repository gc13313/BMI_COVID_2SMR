#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: covid
# Outcome: skin tanning

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)

ao <- available_exposures()

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
#v3
memory.limit(90000)

C2 = fread("COVID19_HGI_ANA_C2_V2_20200701.b37.txt.gz")

C2$samplesize <- C2$all_inv_var_meta_cases+C2$all_inv_var_meta_controls
C2 <- rename(C2, c("CHR"="#CHR", 
                               "SNPid"="SNP",
                               "SNP"="rsid",
                               "effect_allele"="ALT",
                               "other_allele"="REF",
                               "beta"="all_inv_var_meta_beta",
                               "se"="all_inv_var_meta_sebeta",
                               "pval"="all_inv_var_meta_p",
                               "pval.het"="all_inv_var_het_p",
                               "eaf" = "all_meta_AF"))
C2$id <- rep("C2 Covid vs population", nrow(C2))


exposure_dat_C2 <- C2[which(pval<5e-08),]
exposure_dat_C2 <- format_data(exposure_dat_C2, type="exposure")
exposure_dat_C2$exposure <- rep("C2 Covid vs population", nrow(exposure_dat_C2))
exposure_dat_C2 <- clump_data(exposure_dat_C2)

write.xlsx(exposure_dat_C2, file = "exposure_dat_C2_V3.xlsx")
exposure_dat_C2_V3 <- read.xlsx(xlsxFile = "exposure_dat_C2_V3.xlsx")
