#######################################################################
#      TWO SAMPLE MR - BMI and covid MR analyses OUTCOMES         #
#######################################################################
# R version 4.0.2 

# Exposure: BMI
# Outcome: covid

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()
library(tidyverse)
library(readxl)
library(data.table)
#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
exposure_dat <-extract_instruments("ieu-b-40")


#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#covid outcome
memory.limit(64000)

#version 3 20200701. Version 3: released on 2nd July 2020
C2 = fread("COVID19_HGI_ANA_C2_V2_20200701.b37.txt.gz")

C2$outcome <- "C2 Covid vs population"
C2<- rename(C2, c("SNP"="rsid",
                            "chr.outcome"="#CHR", 
                            "effect_allele.outcome"="ALT",
                            "other_allele.outcome"="REF",
                            "beta.outcome"="all_inv_var_meta_beta",
                            "se.outcome"="all_inv_var_meta_sebeta",
                            "pval.outcome"="all_inv_var_meta_p",                              
                            "eaf.outcome" = "all_meta_AF",
                            "SNPid"="SNP",
                            "pval.het"="all_inv_var_het_p"))
C2$id.outcome <- rep("C2 Covid vs population", nrow(C2))


#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_all_b <- harmonise_data(
  exposure_dat = exposure_dat, 
  outcome_dat = C2
)


#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
results_C2_b <- mr(data_all_b, method_list = c("mr_ivw", "mr_egger_regression", 
                                                          "mr_weighted_median", "mr_weighted_mode", "mr_wald_ratio", "mr_two_sample_ml", "mr_uwr"))



write.xlsx(results_C2_b, file = "results_C2_b_v3.xlsx")
results_C2_b_v3 <- read.xlsx(xlsxFile = "results_C2_b_v3.xlsx")


#---------------------------------------------------------------------#
#                   Pleiotropy and Heterogeneity                      #
#---------------------------------------------------------------------#
plt_b <- mr_pleiotropy_test(data_all_b)
het_b <- mr_heterogeneity(data_all_b)

#1 want to merge this with mr egger
p_egger_b<-select(plt_b , id.exposure, id.outcome, pval)

names(p_egger_b)[names(p_egger_b) == 'pval'] <- 'p_egger'
results_egger_b<-subset(results_C2_b, method=="MR Egger")

results_egger_b_plt <- merge(results_egger_b,p_egger_b ,by=c("id.outcome","id.exposure"), all=F)
p_egger_tomerge_b<-select(results_egger_b_plt , id.exposure, id.outcome, p_egger, method)

#2
p_het_b<-select(het_b , id.exposure, id.outcome, method, Q_pval)
p_het_b<-subset(p_het_b, method=="Inverse variance weighted")
results_ivw_b<-subset(results_C2_b, method=="Inverse variance weighted")

p_het_b$cases<-6696
p_het_b$controls<-1073072

#Phenotype
#covid vs. population

#Population
#All

#Total Cases
#6696

#Total Controls
#1073072

#now want to merge back into results_all_b
results_C2_b1<- merge(p_egger_tomerge_b,results_C2_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_C2_b<-results_C2_b1

results_C2_b2<-merge(p_het_b,results_C2_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_C2_b<-results_C2_b2

write.xlsx(results_C2_b, file = "results_C2_b_v3.xlsx", overwrite=T)
results_C2_b_v3 <- read.xlsx(xlsxFile = "results_C2_b_v3.xlsx")

