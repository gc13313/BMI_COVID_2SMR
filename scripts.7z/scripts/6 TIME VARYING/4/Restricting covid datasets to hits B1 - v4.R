#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 


#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)

#ao <- available_exposures()

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
#v4
B1 = fread("COVID19_HGI_B1_ALL_20201020.b37.txt.gz")


head(B1)

B1<- rename(B1, c("SNP"="rsid",
                  "chr.exposure"="#CHR", 
                  "effect_allele.exposure"="ALT",
                  "other_allele.exposure"="REF",
                  "beta.exposure"="all_inv_var_meta_beta",
                  "se.exposure"="all_inv_var_meta_sebeta",
                  "pval.exposure"="all_inv_var_meta_p",                              
                  "eaf.exposure" = "all_meta_AF",
                  "SNPid"="SNP",
                  "pval.het"="all_inv_var_het_p"))
head(B1)
B1$id.exposure <- rep("B1 Hospitalised Covid vs not hospitalised Covid", nrow(B1))


exposure_dat_B1 <- B1[which(pval.exposure<5e-06),]
exposure_dat_B1 <- format_data(exposure_dat_B1, type="exposure")
exposure_dat_B1$exposure <- rep("B1 Hospitalised Covid vs not hospitalised Covid", nrow(exposure_dat_B1))
exposure_dat_B1 <- clump_data(exposure_dat_B1)
#249 of 262 variants removed due to LD; 13 remained

write.xlsx(exposure_dat_B1, file = "exposure_dat_B1_V4_p1.xlsx", overwrite=T)
exposure_dat_B1_V4 <- read.xlsx(xlsxFile = "exposure_dat_B1_V4_p1.xlsx")

#setwd
setwd("")

write.xlsx(exposure_dat_B1, file = "exposure_dat_B1_V4.xlsx", overwrite=T)
exposure_dat_B1_V4 <- read.xlsx(xlsxFile = "exposure_dat_B1_V4.xlsx")




