#######################################################################
#      TWO SAMPLE MR - BMI and covid MR analyses OUTCOMES         #
#######################################################################
# R version 4.1.1

# Exposure: BMI
# Outcome: covid

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()
library(tidyverse)
library(readxl)
library(data.table)
#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
exposure_dat <-extract_instruments("ieu-b-40")


#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#covid outcome

D1_BMI <- extract_outcome_data(snps=exposure_dat$SNP, outcomes="ebi-a-GCST010781",proxies = F)



#---------------------------------------------------------------------#
#                          Combine Outcomes                           #----
#---------------------------------------------------------------------#

out_dat_b <- as.data.frame(rbind(D1_BMI))

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#
data_all_b<- harmonise_data(
  exposure_dat = exposure_dat, 
  outcome_dat = out_dat_b
)



#data_all_b <- harmonise_data( exposure_dat = exposure_dat, outcome_dat = out_dat_b)


#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
results_D1_b <- mr(data_all_b, method_list = c("mr_ivw", "mr_egger_regression", 
                                                          "mr_weighted_median", "mr_weighted_mode", "mr_wald_ratio", "mr_two_sample_ml", "mr_uwr"))


#setwd
setwd("")


write.xlsx(results_D1_b, file = "results_D1_b.xlsx", overwrite=T)
results_D1_b <- read.xlsx(xlsxFile = "results_D1_b.xlsx")



plt_b <- mr_pleiotropy_test(data_all_b)
het_b <- mr_heterogeneity(data_all_b)

write.xlsx(plt_b, file = "plt_D1_b.xlsx", overwrite=T)
plt_b <- read.xlsx(xlsxFile = "plt_D1_b.xlsx")

write.xlsx(het_b, file = "het_D1_b.xlsx", overwrite=T)
het_b <- read.xlsx(xlsxFile = "het_D1_b.xlsx")

#MERGE pleitropy and results - binary
#1 add p-egger intercept to egger res
plt_b <- read.xlsx(xlsxFile = "plt_D1_b.xlsx")
#want to merge this with mr egger
p_egger_b<-select(plt_b , id.exposure, id.outcome, pval)

names(p_egger_b)[names(p_egger_b) == 'pval'] <- 'p_egger'
results_egger_b<-subset(results_D1_b, method=="MR Egger")



results_egger_b_plt <- merge(results_egger_b,p_egger_b ,by=c("id.outcome","id.exposure"), all=F)
p_egger_tomerge_b<-select(results_egger_b_plt , id.exposure, id.outcome, p_egger, method)

#2 add p-q for ivw hetero 
het_b <- read.xlsx(xlsxFile = "het_D1_b.xlsx")
p_het_b<-select(het_b , id.exposure, id.outcome, method, Q_pval)
p_het_b<-subset(p_het_b, method=="Inverse variance weighted")
results_ivw_b<-subset(results_D1_b, method=="Inverse variance weighted")

#now want to merge back into results_all_b
results_D1_b1<- merge(p_egger_tomerge_b,results_D1_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_D1_b<-results_D1_b1
results_D1_b2<-merge(p_het_b,results_D1_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_D1_b<-results_D1_b2


write.xlsx(results_D1_b, file = "results_D1_b.xlsx", overwrite=T)
results_D1_b <- read.xlsx(xlsxFile = "results_D1_b.xlsx")





