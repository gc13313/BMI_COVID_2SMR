#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)


#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#
#setwd
setwd("")

##LOAD DATA
A1 <- read.xlsx("results_A1_b_PROX.xlsx", rowNames = F)
A2 <- read.xlsx("results_A2_b.xlsx", rowNames = F)
B1 <- read.xlsx("results_B1_b.xlsx", rowNames = F)
B2 <- read.xlsx("results_B2_b.xlsx", rowNames = F)
C1 <- read.xlsx("results_C1_b_PROX.xlsx", rowNames = F)
C2 <- read.xlsx("results_C2_b.xlsx", rowNames = F)
D1 <- read.xlsx("results_D1_b_PROX.xlsx", rowNames = F)

BMI_Yengo <- rbind(A1, A2, B1, B2, C1, C2, D1)
BMI_Yengo$group<-"Including UKB"

##LOAD DATA
A1_Locke <- read.xlsx("results_A1_b_locke.xlsx", rowNames = F)
A2_Locke <- read.xlsx("results_A2_b_locke.xlsx", rowNames = F)
B1_Locke <- read.xlsx("results_B1_b_locke.xlsx", rowNames = F)
B2_Locke <- read.xlsx("results_B2_b_locke.xlsx", rowNames = F)
C1_Locke <- read.xlsx("results_C1_b_locke.xlsx", rowNames = F)
C2_Locke <- read.xlsx("results_C2_b_locke.xlsx", rowNames = F)
D1_Locke <- read.xlsx("results_D1_b_locke.xlsx", rowNames = F)

BMI_Locke <- rbind(A1_Locke, A2_Locke, B1_Locke, B2_Locke, C1_Locke, C2_Locke, D1_Locke)
BMI_Locke$group<-"Excluding UKB"

BMI_uni<-rbind(BMI_Yengo, BMI_Locke)
results_all<-subset(BMI_uni, method!="Weighted mode")
results_all<-subset(results_all, method!="Maximum likelihood")
results_all<-subset(results_all, method!="Unweighted regression")
results_all<-subset(results_all, method!="MR Egger")
results_all<-subset(results_all, method!="Weighted median")


results_all$method[results_all$method=="Inverse variance weighted"] <- 'IVW'

results_all$exposure[results_all$exposure=="body mass index || id:ieu-b-40"] <- 'BMI'
results_all$exposure[results_all$exposure=="Body mass index || id:ieu-a-2"] <- 'BMI'
results_all$outcome[results_all$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
results_all$outcome[results_all$id.outcome=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
results_all$outcome[results_all$id.outcome=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'

as.factor(results_all$group)
results_all$group <- factor(results_all$group, levels = c("Including UKB", "Excluding UKB"))

results_all <- arrange(results_all, outcome, group)


a <- metagen(TE = b, seTE = se, data = results_all, 
             studlab = paste(group), sm = "OR",
             hakn = FALSE, subgroup = outcome, fixed = FALSE, random=F)


print(a)

#forest plot
forest_results_SA_b<-forest.meta(a, studlab = T, 
                                 type.study="square",
                                 squaresize=0.5,
                                 lty.random = 2,
                                 bylab = " ",
                                 text.random = "Total", # write anything 
                                 text.random.w = "Total",
                                 smlab="",
                                 col.study = c("deepskyblue", "goldenrod1", 
                                               "deepskyblue", "goldenrod1",
                                               "deepskyblue", "goldenrod1", 
                                               "deepskyblue", "goldenrod1", 
                                               "deepskyblue", "goldenrod1",
                                               "deepskyblue", "goldenrod1", 
                                               "deepskyblue", "goldenrod1") ,    
                                 col.square = c("deepskyblue", "goldenrod1", 
                                                "deepskyblue", "goldenrod1",
                                                "deepskyblue", "goldenrod1", 
                                                "deepskyblue", "goldenrod1", 
                                                "deepskyblue", "goldenrod1",
                                                "deepskyblue", "goldenrod1", 
                                                "deepskyblue", "goldenrod1") , 
                                 col.diamond="white", 
                                 col.diamond.lines="black",
                                 col.label.right="black",
                                 col.label.left="black", 
                                 colgap.right = "0.5cm",
                                 colgap.forest.left ="0.5cm",
                                 col.by = "black",
                                 xlab="OR per SD increase in BMI", 
                                 leftcols=c("studlab", "nsnp"),# To remove "logHR" and "seHR" from plot
                                 leftlabs = c("Outcome", "SNPs"),
                                 rightcols=c("effect", "ci", "Q_pval"),
                                 rightlabs=c("OR","[95% CI]","p-het"),
                                 test.overall = F,
                                 lwd=3,
                                 print.I2 = a$comb.fixed,
                                 plotwidth="10.5cm",
                                 print.I2.ci = FALSE, 
                                 print.tau2 = F, 
                                 print.Q = FALSE,
                                 print.subgroup.name=F,
                                 digits.mean = 2,
                                 digits.addcols.right = 3,
                                 fontsize = 12,
                                 overall = FALSE,
                                 overall.hetstat = FALSE,
                                 test.subgroup.fixed=FALSE,
                                 fixed=F)

forest_results_SA_b <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=2600, width=3200)
  print(plot_name)
  dev.off()
}


save_func("forest_BMI_covid_by_yengo_locke_S4.png", forest_results_SA_b)

