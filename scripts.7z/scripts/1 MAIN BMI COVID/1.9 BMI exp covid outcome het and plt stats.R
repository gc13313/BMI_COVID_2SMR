#######################################################################
#      TWO SAMPLE MR - BMI and covid MR analyses OUTCOMES         #
#######################################################################
# R version 4.1.1 

# Exposure: BMI
# Outcome: covid

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()
library(tidyverse)
library(readxl)
library(data.table)
#---------------------------------------------------------------------#
#                           READ IN SAVED RES                                 #
#---------------------------------------------------------------------#
#setwd
setwd("")


het_b_A1 <- read.xlsx(xlsxFile = "het_A1_b.xlsx")
het_b_A2 <- read.xlsx(xlsxFile = "het_A2_b.xlsx")
het_b_B1 <- read.xlsx(xlsxFile = "het_B1_b.xlsx")
het_b_B2 <- read.xlsx(xlsxFile = "het_B2_b.xlsx")
het_b_C1 <- read.xlsx(xlsxFile = "het_C1_b.xlsx")
het_b_C2 <- read.xlsx(xlsxFile = "het_C2_b.xlsx")
het_b_D1 <- read.xlsx(xlsxFile = "het_D1_b.xlsx")

het_b_A1$outcome[het_b_A1$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
het_b_C1$outcome[het_b_C1$id.outcome=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
het_b_D1$outcome[het_b_D1$id.outcome=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'




het_b_bmicovid <- rbind(het_b_A1, het_b_A2, het_b_B1, het_b_B2, het_b_C1, het_b_C2, het_b_D1)

plt_b_A1 <- read.xlsx(xlsxFile = "plt_A1_b.xlsx")
plt_b_A2 <- read.xlsx(xlsxFile = "plt_A2_b.xlsx")
plt_b_B1 <- read.xlsx(xlsxFile = "plt_B1_b.xlsx")
plt_b_B2 <- read.xlsx(xlsxFile = "plt_B2_b.xlsx")
plt_b_C1 <- read.xlsx(xlsxFile = "plt_C1_b.xlsx")
plt_b_C2 <- read.xlsx(xlsxFile = "plt_C2_b.xlsx")
plt_b_D1 <- read.xlsx(xlsxFile = "plt_D1_b.xlsx")

plt_b_A1$outcome[plt_b_A1$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
plt_b_C1$outcome[plt_b_C1$id.outcome=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
plt_b_D1$outcome[plt_b_D1$id.outcome=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'





plt_b_bmicovid <- rbind(plt_b_A1, plt_b_A2, plt_b_B1, plt_b_B2, plt_b_C1, plt_b_C2, plt_b_D1)

het_b_bmicovid$method[het_b_bmicovid$method=="Inverse variance weighted"] <- 'IVW'
as.factor(het_b_bmicovid$method)
het_b_bmicovid$method <- factor(het_b_bmicovid$method, levels = c("IVW", "MR Egger"))
het_b_bmicovid <- arrange(het_b_bmicovid, outcome, method)


write.xlsx(het_b_bmicovid, file = "het_b_bmicovid_ST5.xlsx", overwrite=T)
het_b_bmicovid <- read.xlsx(xlsxFile = "het_b_bmicovid_ST5.xlsx")


write.xlsx(plt_b_bmicovid, file = "plt_b_bmicovid_ST4.xlsx", overwrite=T)
plt_b_bmicovid <- read.xlsx(xlsxFile = "plt_b_bmicovid_ST4.xlsx")

