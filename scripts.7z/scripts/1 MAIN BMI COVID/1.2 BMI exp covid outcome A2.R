#######################################################################
#      TWO SAMPLE MR - BMI and COVID MR analyses OUTCOMES         #
#######################################################################
# R version 4.1.1 

# Exposure: BMI
# Outcome: COVID

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()
library(tidyverse)
library(readxl)
library(data.table)
#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#

exposure_dat <-extract_instruments("ieu-b-40")


#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#Covid outcome

## Extract Covid data: Very severe Covid vs population - release 6
A2 = fread("COVID19_HGI_A2_ALL_leave_23andme_20210607.b37.txt.gz")

A2$outcome <- "A2 Very severe Covid vs population"
A2<- rename(A2, c("SNP"="rsid",
                            "chr.outcome"="#CHR", 
                            "effect_allele.outcome"="ALT",
                            "other_allele.outcome"="REF",
                            "beta.outcome"="all_inv_var_meta_beta",
                            "se.outcome"="all_inv_var_meta_sebeta",
                            "pval.outcome"="all_inv_var_meta_p",                              
                            "eaf.outcome" = "all_meta_AF",
                            "SNPid"="SNP",
                            "pval.het"="all_inv_var_het_p"))
A2$id.outcome <- rep("A2 Very severe Covid vs population", nrow(A2))


#---------------------------------------------------------------------#
#                          Combine Outcomes                           #----
#---------------------------------------------------------------------#

out_dat_b <- as.data.frame(rbind(A2))

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_all_b <- harmonise_data(
  exposure_dat = exposure_dat, 
  outcome_dat = out_dat_b
)


#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
mr_method_list()
results_A2_b <- mr(data_all_b, method_list = c("mr_ivw", "mr_egger_regression", 
                                                          "mr_weighted_median", "mr_weighted_mode", "mr_wald_ratio", "mr_two_sample_ml", "mr_uwr"))


#setwd
setwd("")


write.xlsx(results_A2_b, file = "results_A2_b.xlsx", overwrite=T)
results_A2_b <- read.xlsx(xlsxFile = "results_A2_b.xlsx")

plt_b <- mr_pleiotropy_test(data_all_b)
het_b <- mr_heterogeneity(data_all_b)

write.xlsx(plt_b, file = "plt_A2_b.xlsx", overwrite=T)
plt_b <- read.xlsx(xlsxFile = "plt_A2_b.xlsx")

write.xlsx(het_b, file = "het_A2_b.xlsx", overwrite=T)
het_b <- read.xlsx(xlsxFile = "het_A2_b.xlsx")

#MERGE pleitropy and results - binary
#1 add p-egger intercept to egger res
plt_b <- read.xlsx(xlsxFile = "plt_A2_b.xlsx")
#want to merge this with mr egger
p_egger_b<-select(plt_b , id.exposure, id.outcome, pval)

names(p_egger_b)[names(p_egger_b) == 'pval'] <- 'p_egger'
results_egger_b<-subset(results_A2_b, method=="MR Egger")

results_egger_b_plt <- merge(results_egger_b,p_egger_b ,by=c("id.outcome","id.exposure"), all=F)
p_egger_tomerge_b<-select(results_egger_b_plt , id.exposure, id.outcome, p_egger, method)

#2 add p-q for ivw hetero 
het_b <- read.xlsx(xlsxFile = "het_A2_b.xlsx")
p_het_b<-select(het_b , id.exposure, id.outcome, method, Q_pval)
p_het_b<-subset(p_het_b, method=="Inverse variance weighted")
results_ivw_b<-subset(results_A2_b, method=="Inverse variance weighted")

#now want to merge back into results_all_b
results_A2_b1<- merge(p_egger_tomerge_b,results_A2_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_A2_b<-results_A2_b1
results_A2_b2<-merge(p_het_b,results_A2_b ,by=c("id.outcome","id.exposure", "method"), all=T)
results_A2_b<-results_A2_b2


write.xlsx(results_A2_b, file = "results_A2_b.xlsx", overwrite=T)
results_A2_b <- read.xlsx(xlsxFile = "results_A2_b.xlsx")