#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)


#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#
#setwd
setwd("")


##LOAD DATA
A1 <- read.xlsx("results_A1_b_PROX.xlsx", rowNames = F)
A2 <- read.xlsx("results_A2_b.xlsx", rowNames = F)
B1 <- read.xlsx("results_B1_b.xlsx", rowNames = F)
B2 <- read.xlsx("results_B2_b.xlsx", rowNames = F)
C1 <- read.xlsx("results_C1_b_PROX.xlsx", rowNames = F)
C2 <- read.xlsx("results_C2_b.xlsx", rowNames = F)
D1 <- read.xlsx("results_D1_b_PROX.xlsx", rowNames = F)

BMI_uni <- rbind(A1, A2, B1, B2, C1, C2, D1)

results_all<-subset(BMI_uni, method!="Weighted mode")
results_all<-subset(results_all, method!="Maximum likelihood")
results_all<-subset(results_all, method!="Unweighted regression")
results_all<-subset(results_all, method!="MR Egger")
results_all<-subset(results_all, method!="Weighted median")


results_all$method[results_all$method=="Inverse variance weighted"] <- 'IVW'

results_all$exposure[results_all$exposure=="body mass index || id:ieu-b-40"] <- 'BMI'

results_all$outcome[results_all$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
results_all$outcome[results_all$id.outcome=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
results_all$outcome[results_all$id.outcome=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'

a <- metagen(TE = b, seTE = se, data = results_all, 
             studlab = paste(method), sm = "OR",
             hakn = FALSE, byvar = outcome, comb.fixed = FALSE, comb.random=F)


print(a)

#forest plot
forest_results_SA_b<-forest.meta(a, studlab = T, 
                                 type.study="square",
                                 squaresize=0.5,
                                 lty.random = 2,
                                 bylab = " ",
                                 text.random = "Total", # write anything 
                                 text.random.w = "Total",
                                 col.study = c("deepskyblue",
                                               "deepskyblue", 
                                               "deepskyblue",
                                               "deepskyblue", 
                                               "deepskyblue",
                                               "deepskyblue", 
                                               "deepskyblue") ,    
                                 col.square = c("deepskyblue",
                                                "deepskyblue", 
                                                "deepskyblue",
                                                "deepskyblue", 
                                                "deepskyblue",
                                                "deepskyblue", 
                                                "deepskyblue") , 
                                 col.diamond="white", 
                                 col.diamond.lines="black",
                                 col.label.right="black",
                                 col.label.left="black", 
                                 colgap.right = "0.1cm",
                                 colgap.forest.left ="1.9cm",
                                 colgap.forest.right ="0.1cm",
                                 col.by = "black",
                                 xlab="OR per SD increase in BMI", 
                                 leftcols=c("studlab", "nsnp"),# To remove "logHR" and "seHR" from plot
                                 leftlabs = c("Outcome", "SNPs"),
                                 rightcols=c("effect", "ci"),
                                 rightlabs=c("OR","[95% CI]"),
                                 test.overall = F,
                                 lwd=3,
                                 print.I2 = a$comb.fixed,
                                 plotwidth="6.5cm",
                                 print.I2.ci = FALSE, 
                                 print.tau2 = F, 
                                 print.Q = FALSE,
                                 print.subgroup.name=F,
                                 digits.mean = 2,
                                 digits.addcols.right = 3,
                                 fontsize = 12,
                                 overall = FALSE,
                                 overall.hetstat = FALSE,
                                 test.subgroup.fixed=FALSE,
                                 fixed=F,
                                 smlab="",
                                 at=c(0.25, 0.5, 1, 1.5, 2))

forest_results_SA_b <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=3200, width=2600)
  print(plot_name)
  dev.off()
}


save_func("forest_BMI_covid_all_prox_IVW_2a.png", forest_results_SA_b)

