#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: covid
# Outcome: BMI

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)

#setwd
setwd("")

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
exposure_dat_A1 <-extract_instruments("ebi-a-GCST010775", p1 = 5e-06)
exposure_dat_A12 <-extract_instruments("ebi-a-GCST010775", p1 = 5e-08)
#0 FOR A1
exposure_dat_C1 <-extract_instruments("ebi-a-GCST010778", p1 = 5e-06)
exposure_dat_C12 <-extract_instruments("ebi-a-GCST010778", p1 = 5e-08)
#1 FOR C1
exposure_dat_D1 <-extract_instruments("ebi-a-GCST010781", p1 = 5e-06)
exposure_dat_D12 <-extract_instruments("ebi-a-GCST010781", p1 = 5e-08)
#0 FOR D1
#exposure_dat_A1 <- read.xlsx(xlsxFile = "exposure_dat_A1.xlsx")
exposure_dat_A2 <- read.xlsx(xlsxFile = "exposure_dat_A2.xlsx")
exposure_dat_B1 <- read.xlsx(xlsxFile = "exposure_dat_B1.xlsx")
exposure_dat_B2 <- read.xlsx(xlsxFile = "exposure_dat_B2.xlsx")
#exposure_dat_C1 <- read.xlsx(xlsxFile = "exposure_dat_C1.xlsx")
exposure_dat_C2 <- read.xlsx(xlsxFile = "exposure_dat_C2.xlsx")
#exposure_dat_D1 <- read.xlsx(xlsxFile = "exposure_dat_D1.xlsx")

#---------------------------------------------------------------------#
#                          Combine exposures                          #
#---------------------------------------------------------------------#

#Should have the following cols:
head(exposure_dat_A2)
head(exposure_dat_C2)
head(exposure_dat_D1)
head(exposure_dat_A1)
head(exposure_dat_C1)
head(exposure_dat_B1)
head(exposure_dat_B2)
#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#BMI
BMI_A1 <- extract_outcome_data(snps=exposure_dat_A1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_A2 <- extract_outcome_data(snps=exposure_dat_A2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B1 <- extract_outcome_data(snps=exposure_dat_B1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B2 <- extract_outcome_data(snps=exposure_dat_B2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C1 <- extract_outcome_data(snps=exposure_dat_C1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C2 <- extract_outcome_data(snps=exposure_dat_C2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_D1 <- extract_outcome_data(snps=exposure_dat_D1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_D1_noprox <- extract_outcome_data(snps=exposure_dat_D1$SNP, outcomes="ieu-b-40", proxies = F)

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_A1_c <- harmonise_data(exposure_dat = exposure_dat_A1, outcome_dat = BMI_A1, action=2)
data_A2_c <- harmonise_data(exposure_dat = exposure_dat_A2, outcome_dat = BMI_A2, action=2)
data_B1_c <- harmonise_data(exposure_dat = exposure_dat_B1, outcome_dat = BMI_B1, action=2)
data_B2_c <- harmonise_data(exposure_dat = exposure_dat_B2, outcome_dat = BMI_B2, action=2)
data_C1_c <- harmonise_data(exposure_dat = exposure_dat_C1, outcome_dat = BMI_C1, action=2)
data_C2_c <- harmonise_data(exposure_dat = exposure_dat_C2, outcome_dat = BMI_C2, action=2)
data_D1_c <- harmonise_data(exposure_dat = exposure_dat_D1, outcome_dat = BMI_D1, action=2)
data_D1_c_noprox <- harmonise_data(exposure_dat = exposure_dat_D1, outcome_dat = BMI_D1_noprox, action=2)

#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
#mr_method_list()

results_A1_c <- mr(data_A1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_A2_c <- mr(data_A2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B1_c <- mr(data_B1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B2_c <- mr(data_B2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C1_c <- mr(data_C1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C2_c <- mr(data_C2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_D1_c <- mr(data_D1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))


results_all_c <- rbind(results_A1_c, results_A2_c, results_B1_c, results_B2_c, results_C1_c, results_C2_c, results_D1_c)

results_all_c$id.exposure[results_all_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
results_all_c$id.exposure[results_all_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
results_all_c$id.exposure[results_all_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'

results_all_c$exposure[results_all_c$exposure==" || id:ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
results_all_c$exposure[results_all_c$exposure==" || id:ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
results_all_c$exposure[results_all_c$exposure==" || id:ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'


write.xlsx(results_all_c, file = "results_all_c.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "results_all_c.xlsx")

plt_A1_c <- mr_pleiotropy_test(data_A1_c)
het_A1_c <- mr_heterogeneity(data_A1_c)

plt_A2_c <- mr_pleiotropy_test(data_A2_c)
het_A2_c <- mr_heterogeneity(data_A2_c)

plt_B1_c <- mr_pleiotropy_test(data_B1_c)
het_B1_c <- mr_heterogeneity(data_B1_c)

plt_B2_c <- mr_pleiotropy_test(data_B2_c)
het_B2_c <- mr_heterogeneity(data_B2_c)

plt_C1_c <- mr_pleiotropy_test(data_C1_c)
het_C1_c <- mr_heterogeneity(data_C1_c)

plt_C2_c <- mr_pleiotropy_test(data_C2_c)
het_C2_c <- mr_heterogeneity(data_C2_c)

plt_D1_c <- mr_pleiotropy_test(data_D1_c)
het_D1_c <- mr_heterogeneity(data_D1_c)

het_c <- rbind(het_A1_c, het_A2_c, het_B1_c, het_B2_c, het_C1_c, het_C2_c, het_D1_c)
plt_c <- rbind(plt_A1_c, plt_A2_c, plt_B1_c, plt_B2_c, plt_C1_c, plt_C2_c, plt_D1_c)

plt_c$exposure[plt_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
plt_c$exposure[plt_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
plt_c$exposure[plt_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'
plt_c$id.exposure[plt_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
plt_c$id.exposure[plt_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
plt_c$id.exposure[plt_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'




het_c$exposure[het_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
het_c$exposure[het_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
het_c$exposure[het_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'
het_c$id.exposure[het_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
het_c$id.exposure[het_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
het_c$id.exposure[het_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'




write.xlsx(plt_c, file = "plt_c_ST4.xlsx", overwrite=T)
plt_c <- read.xlsx(xlsxFile = "plt_c_ST4.xlsx")

write.xlsx(het_c, file = "het_c_ST5.xlsx", overwrite=T)
het_c <- read.xlsx(xlsxFile = "het_c_ST5.xlsx")

#MERGE pleitropy and results - binary
#1 add p-egger intercept to egger res
plt_c <- read.xlsx(xlsxFile = "plt_c_ST4.xlsx")
#want to merge this with mr egger
p_egger_c<-select(plt_c , id.exposure, id.outcome, pval)

names(p_egger_c)[names(p_egger_c) == 'pval'] <- 'p_egger'
results_egger_c<-subset(results_all_c, method=="MR Egger")



results_egger_c_plt <- merge(results_egger_c,p_egger_c ,by=c("id.outcome","id.exposure"), all=F)
p_egger_tomerge_c<-select(results_egger_c_plt , id.exposure, id.outcome, p_egger, method)

#2 add p-q for ivw hetero 
het_c <- read.xlsx(xlsxFile = "het_c_ST5.xlsx")
p_het_c<-select(het_c , id.exposure, id.outcome, method, Q_pval)
p_het_c<-subset(p_het_c, method=="Inverse variance weighted")
results_ivw_c<-subset(results_all_c, method=="Inverse variance weighted")

#now want to merge back into results_all_b
results_all_c1<- merge(p_egger_tomerge_c,results_all_c ,by=c("id.outcome","id.exposure", "method"), all=T)
results_all_c<-results_all_c1
results_all_c2<-merge(p_het_c,results_all_c ,by=c("id.outcome","id.exposure", "method"), all=T)
results_all_c<-results_all_c2


write.xlsx(results_all_c, file = "results_all_c.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "results_all_c.xlsx")

