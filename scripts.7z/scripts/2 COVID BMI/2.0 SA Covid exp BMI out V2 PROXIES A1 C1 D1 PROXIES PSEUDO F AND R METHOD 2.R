#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.1.1 

# Exposure: covid
# Outcome: BMI

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
library(gtools)



#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
exposure_dat_A1 <-extract_instruments("ebi-a-GCST010775", p1 = 5e-06)
exposure_dat_C1 <-extract_instruments("ebi-a-GCST010778", p1 = 5e-06)
exposure_dat_D1 <-extract_instruments("ebi-a-GCST010781", p1 = 5e-06)

exposure_dat_A2 <- read.xlsx(xlsxFile = "exposure_dat_A2.xlsx")
exposure_dat_B1 <- read.xlsx(xlsxFile = "exposure_dat_B1.xlsx")
exposure_dat_B2 <- read.xlsx(xlsxFile = "exposure_dat_B2.xlsx")
exposure_dat_C2 <- read.xlsx(xlsxFile = "exposure_dat_C2.xlsx")

#---------------------------------------------------------------------#
#                          Combine exposures                          #
#---------------------------------------------------------------------#

#Should have the following cols:
head(exposure_dat_A2)
head(exposure_dat_C2)
head(exposure_dat_D1)
head(exposure_dat_A1)
head(exposure_dat_C1)
head(exposure_dat_B1)
head(exposure_dat_B2)

exposure_dat_B1$samplesize.exposure<-exposure_dat_B1$all_inv_var_meta_cases+exposure_dat_B1$all_inv_var_meta_controls
exposure_dat_B2$samplesize.exposure<-exposure_dat_B2$all_inv_var_meta_cases+exposure_dat_B2$all_inv_var_meta_controls

exposure_dat <- smartbind(exposure_dat_A1, exposure_dat_A2, exposure_dat_B1, exposure_dat_B2, exposure_dat_C1, exposure_dat_C2, exposure_dat_D1)

exposure_dat$exposure[exposure_dat$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
exposure_dat$exposure[exposure_dat$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
exposure_dat$exposure[exposure_dat$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'


#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#BMI - number of cigarettes
BMI_A1 <- extract_outcome_data(snps=exposure_dat_A1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_A2 <- extract_outcome_data(snps=exposure_dat_A2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B1 <- extract_outcome_data(snps=exposure_dat_B1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B2 <- extract_outcome_data(snps=exposure_dat_B2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C1 <- extract_outcome_data(snps=exposure_dat_C1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C2 <- extract_outcome_data(snps=exposure_dat_C2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_D1 <- extract_outcome_data(snps=exposure_dat_D1$SNP, outcomes="ieu-b-40", proxies = T)

covid_BMI_extract <- smartbind(BMI_A1, BMI_A2, BMI_B1, BMI_B2, BMI_C1, BMI_C2, BMI_D1)




covid_bmi_preharm <- subset(exposure_dat, select=c("exposure","samplesize.exposure","SNP", "effect_allele.exposure", "other_allele.exposure", "eaf.exposure", "beta.exposure", "se.exposure", "pval.exposure"))




covid_bmi_preharm$F<-((covid_bmi_preharm$beta.exposure)^2)/((covid_bmi_preharm$se.exposure)^2)

covid_bmi_preharm$r2 <- (2 * (covid_bmi_preharm$beta.exposure^2) * covid_bmi_preharm$eaf.exposure * (1 - covid_bmi_preharm$eaf.exposure)) /
  (2 * (covid_bmi_preharm$beta.exposure^2) * covid_bmi_preharm$eaf.exposure * (1 - covid_bmi_preharm$eaf.exposure) +
     2 * covid_bmi_preharm$samplesize.exposure *covid_bmi_preharm$eaf.exposure * (1 - covid_bmi_preharm$eaf.exposure) *covid_bmi_preharm$se.exposure^2)

covid_bmi_preharm$F2 <- covid_bmi_preharm$r2 * (covid_bmi_preharm$samplesize.exposure - 2) / (1 - covid_bmi_preharm$r2)



write.xlsx(covid_bmi_preharm , file = "covid_bmi_preharm_ST6.xlsx", overwrite=T)



#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_A1_c <- harmonise_data(exposure_dat = exposure_dat_A1, outcome_dat = BMI_A1, action=2)
data_A2_c <- harmonise_data(exposure_dat = exposure_dat_A2, outcome_dat = BMI_A2, action=2)
data_B1_c <- harmonise_data(exposure_dat = exposure_dat_B1, outcome_dat = BMI_B1, action=2)
data_B2_c <- harmonise_data(exposure_dat = exposure_dat_B2, outcome_dat = BMI_B2, action=2)
data_C1_c <- harmonise_data(exposure_dat = exposure_dat_C1, outcome_dat = BMI_C1, action=2)
data_C2_c <- harmonise_data(exposure_dat = exposure_dat_C2, outcome_dat = BMI_C2, action=2)
data_D1_c <- harmonise_data(exposure_dat = exposure_dat_D1, outcome_dat = BMI_D1, action=2)


covid_bmi_postharm <- smartbind(data_A1_c, data_A2_c, data_B1_c,data_B2_c, data_C1_c, data_C2_c, data_D1_c)

covid_bmi_postharm$exposure[covid_bmi_postharm$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
covid_bmi_postharm$exposure[covid_bmi_postharm$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
covid_bmi_postharm$exposure[covid_bmi_postharm$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'


covid_bmi_postharm <- subset(covid_bmi_postharm, select=c("exposure","samplesize.exposure","SNP", "effect_allele.exposure", "other_allele.exposure", "eaf.exposure", "beta.exposure", "se.exposure", "pval.exposure"))

write.xlsx(covid_bmi_postharm , file = "covid_bmi_postharm_ST6.xlsx", overwrite=T)

