#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)

#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#
#setwd
setwd("")

##LOAD DATA
results_all_c <- read.xlsx(xlsxFile = "results_all_c.xlsx")

results_all_c$method[results_all_c$method=="Inverse variance weighted"] <- 'IVW'

results_all_c$exposure[results_all_c$id.exposure=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
results_all_c$exposure[results_all_c$id.exposure=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
results_all_c$exposure[results_all_c$id.exposure=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'

results_all_c<-subset(results_all_c, method!="MR Egger")
results_all_c<-subset(results_all_c, method!="Weighted median")

as.factor(results_all_c$exposure)
results_all_c <- arrange(results_all_c, exposure)

a <- metagen(TE = b, seTE = se, data = results_all_c, 
             studlab = paste(method), sm = "MD",
             hakn = FALSE, subgroup = exposure, fixed = F, random=F)


print(a)

#forest plot
forest_results_c <-forest.meta(a, studlab = T, 
                                          type.study="square",
                                          squaresize=0.5,
                                          lty.random = 2,
                                          bylab = " ",
                                          text.random = "Total", # write anything 
                                          text.random.w = "Total",
                                          col.study = c("deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue", 
                                                        "deepskyblue",
                                                        "deepskyblue") ,    
                                          col.square = c("deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue", 
                                                         "deepskyblue",
                                                         "deepskyblue") , 
                                          col.diamond="white", 
                                          col.diamond.lines="black",
                                          col.label.right="black",
                                          col.label.left="black", 
                                         colgap.right = "0.1cm",
                               colgap.forest.left ="1.9cm",
                               colgap.forest.right ="0.1cm",
                                          col.by = "black",
                                          title="",
                                          xlab="Difference in mean BMI", 
                                          leftcols=c("studlab", "nsnp"),# To remove "logHR" and "seHR" from plot
                                          leftlabs = c("Outcome", "SNPs"),
                                          rightcols=c("effect", "ci"),
                                          rightlabs=c("MD","[95% CI]"),
                                          test.overall = F,
                                          lwd=3,
                                          print.I2 = a$comb.fixed,
                                          plotwidth="6.5cm",
                                          print.I2.ci = FALSE, 
                                          print.tau2 = F, 
                                          print.Q = FALSE,
                                          print.subgroup.name=F,
                                          digits.mean = 4,
                                          digits = 3,
                                          digits.addcols.right = 3,
                                          fontsize = 12,
                                          overall = FALSE,
                                          overall.hetstat = FALSE,
                                          test.subgroup.fixed=FALSE,
                                          fixed=F, smlab="")
forest_results_c <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300,  height=3200, width=2600)
  print(plot_name)
  dev.off()
}


save_func("forest_covid_BMI_IVW_2b.png", forest_results_c)





