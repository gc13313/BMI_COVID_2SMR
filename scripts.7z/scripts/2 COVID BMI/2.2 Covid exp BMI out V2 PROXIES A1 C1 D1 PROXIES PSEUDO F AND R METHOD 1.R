#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: covid
# Outcome: BMI

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)


#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
exposure_dat_A1 <-extract_instruments("ebi-a-GCST010775", p1 = 5e-06)
exposure_dat_C1 <-extract_instruments("ebi-a-GCST010778", p1 = 5e-06)
exposure_dat_D1 <-extract_instruments("ebi-a-GCST010781", p1 = 5e-06)

#exposure_dat_A1 <- read.xlsx(xlsxFile = "exposure_dat_A1.xlsx")
exposure_dat_A2 <- read.xlsx(xlsxFile = "exposure_dat_A2.xlsx")
exposure_dat_B1 <- read.xlsx(xlsxFile = "exposure_dat_B1.xlsx")
exposure_dat_B2 <- read.xlsx(xlsxFile = "exposure_dat_B2.xlsx")
#exposure_dat_C1 <- read.xlsx(xlsxFile = "exposure_dat_C1.xlsx")
exposure_dat_C2 <- read.xlsx(xlsxFile = "exposure_dat_C2.xlsx")
#exposure_dat_D1 <- read.xlsx(xlsxFile = "exposure_dat_D1.xlsx")

#---------------------------------------------------------------------#
#                          Combine exposures                          #
#---------------------------------------------------------------------#

#Should have the following cols:
head(exposure_dat_A2)
head(exposure_dat_C2)
head(exposure_dat_D1)
head(exposure_dat_A1)
head(exposure_dat_C1)
head(exposure_dat_B1)
head(exposure_dat_B2)
#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#BMI
BMI_A1 <- extract_outcome_data(snps=exposure_dat_A1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_A2 <- extract_outcome_data(snps=exposure_dat_A2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B1 <- extract_outcome_data(snps=exposure_dat_B1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_B2 <- extract_outcome_data(snps=exposure_dat_B2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C1 <- extract_outcome_data(snps=exposure_dat_C1$SNP, outcomes="ieu-b-40", proxies = T)
BMI_C2 <- extract_outcome_data(snps=exposure_dat_C2$SNP, outcomes="ieu-b-40", proxies = T)
BMI_D1 <- extract_outcome_data(snps=exposure_dat_D1$SNP, outcomes="ieu-b-40", proxies = T)

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_A1_c <- harmonise_data(exposure_dat = exposure_dat_A1, outcome_dat = BMI_A1, action=2)
data_A2_c <- harmonise_data(exposure_dat = exposure_dat_A2, outcome_dat = BMI_A2, action=2)
data_B1_c <- harmonise_data(exposure_dat = exposure_dat_B1, outcome_dat = BMI_B1, action=2)
data_B2_c <- harmonise_data(exposure_dat = exposure_dat_B2, outcome_dat = BMI_B2, action=2)
data_C1_c <- harmonise_data(exposure_dat = exposure_dat_C1, outcome_dat = BMI_C1, action=2)
data_C2_c <- harmonise_data(exposure_dat = exposure_dat_C2, outcome_dat = BMI_C2, action=2)
data_D1_c <- harmonise_data(exposure_dat = exposure_dat_D1, outcome_dat = BMI_D1, action=2)

#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
#mr_method_list()

results_A1_c <- mr(data_A1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_A2_c <- mr(data_A2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B1_c <- mr(data_B1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B2_c <- mr(data_B2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C1_c <- mr(data_C1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C2_c <- mr(data_C2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_D1_c <- mr(data_D1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))


results_all_c <- rbind(results_A1_c, results_A2_c, results_B1_c, results_B2_c, results_C1_c, results_C2_c, results_D1_c)

#A1
#data_A1_c 269	688
head(data_A1_c)
lor_A1 <- data_A1_c$beta.exposure
af_A1 <- data_A1_c$eaf.exposure
ncase_A1 <- 269
ncontrol_A1 <- 688
prevalence_A1 <- rep(c(0.08), times = 4) # prevalence from literature

r.exposure_A1 <- get_r_from_lor(lor_A1, af_A1, ncase_A1, ncontrol_A1, prevalence_A1, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_A1 <- sum(r.exposure_A1^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_A1 <- (r2_exp_A1*(957-1-4))/((1-r2_exp_A1)*4)
# R^2 for exposure is
r2_exp_A1  
# F-statistic is
f_stat_A1  

############################################################################
#A2
#data_A1_c 8,779	1,001875
head(data_A2_c)
lor_A2 <- data_A2_c$beta.exposure
af_A2 <- data_A2_c$eaf.exposure
ncase_A2 <- 8779
ncontrol_A2 <- 1001875
prevalence_A2 <- rep(c(0.04), times = 7) # prevalence from literature

r.exposure_A2 <- get_r_from_lor(lor_A2, af_A2, ncase_A2, ncontrol_A2, prevalence_A2, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_A2 <- sum(r.exposure_A2^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_A2 <- (r2_exp_A2*(1090000-1-7))/((1-r2_exp_A2)*7)
# R^2 for exposure is
r2_exp_A2  
# F-statistic is
f_stat_A2 
################################################################################
#B1
#data_A1_c14,480 73,191

head(data_B1_c)
lor_B1 <- data_B1_c$beta.exposure
af_B1 <- data_B1_c$eaf.exposure
ncase_B1 <- 14480
ncontrol_B1 <- 73191
prevalence_B1 <- rep(c(0.10), times = 2) # prevalence from literature

r.exposure_B1 <- get_r_from_lor(lor_B1, af_B1, ncase_B1, ncontrol_B1, prevalence_B1, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_B1 <- sum(r.exposure_B1^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_B1 <- (r2_exp_B1*(87000-1-7))/((1-r2_exp_B1)*7)
# R^2 for exposure is
r2_exp_B1  
# F-statistic is
f_stat_B1
###################################################################
#B2
#data_A1_c 24,274  2,061,529


head(data_B2_c)
lor_B2 <- data_B2_c$beta.exposure
af_B2 <- data_B2_c$eaf.exposure
ncase_B2 <- 24274
ncontrol_B2 <- 2061529
prevalence_B2 <- rep(c(0.03), times = 8) # prevalence  from literature

r.exposure_B2 <- get_r_from_lor(lor_B2, af_B2, ncase_B2, ncontrol_B2, prevalence_B2, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_B2 <- sum(r.exposure_B2^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_B2 <- (r2_exp_B2*(2065000-1-8))/((1-r2_exp_B2)*8)
# R^2 for exposure is
r2_exp_B2  
# F-statistic is
f_stat_B2
data_B2_c$samplesize.exposure<-data_B2_c$all_inv_var_meta_cases+data_B2_c$all_inv_var_meta_controls
F_B2 <- r.exposure_B2^2 * (data_B2_c$samplesize.exposure - 2) / (1 - r.exposure_B2^2)
data_B2_c$F_B2<- r.exposure_B2^2 * (data_B2_c$samplesize.exposure - 2) / (1 - r.exposure_B2^2)


###############################################################################

#C1
#data_A1_c 24,057	218,062
head(data_C1_c)
lor_C1 <- data_C1_c$beta.exposure
af_C1 <- data_C1_c$eaf.exposure
ncase_C1 <- 24057
ncontrol_C1 <- 218062
prevalence_C1 <- rep(c(0.10), times = 7) # prevalence from literature

r.exposure_C1 <- get_r_from_lor(lor_C1, af_C1, ncase_C1, ncontrol_C1, prevalence_C1, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_C1 <- sum(r.exposure_C1^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_C1 <- (r2_exp_C1*(250000-1-7))/((1-r2_exp_C1)*7)
# R^2 for exposure is
r2_exp_C1  
# F-statistic is
f_stat_C1


F_C1 <- r.exposure_C1^2 * (data_C1_c$samplesize.exposure - 2) / (1 - r.exposure_C1^2)
data_C1_c$F_C1<- r.exposure_C1^2 * (data_C1_c$samplesize.exposure - 2) / (1 - r.exposure_C1^2)
#################################################
#C2
#data_A1_c 112,612 2,474,079


head(data_C2_c)
lor_C2 <- data_C2_c$beta.exposure
af_C2 <- data_C2_c$eaf.exposure
ncase_C2 <- 112612
ncontrol_C2 <- 2474079
prevalence_C2 <- rep(c(0.05), times = 4) # prevalence from literature

r.exposure_C2 <- get_r_from_lor(lor_C2, af_C2, ncase_C2, ncontrol_C2, prevalence_C2, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_C2 <- sum(r.exposure_C2^2)
# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_C2 <- (r2_exp_C2*(2500000-1-4))/((1-r2_exp_C2)*4)
# R^2 for exposure is
r2_exp_C2  
# F-statistic is
f_stat_C2

F_C2 <- r.exposure_C2^2 * (data_C2_c$samplesize.exposure - 2) / (1 - r.exposure_C2^2)


###############################################################
#D1
#data_A1_c 3,204	35,728
head(data_D1_c)
lor_D1 <- data_D1_c$beta.exposure
af_D1 <- data_D1_c$eaf.exposure
ncase_D1 <- 3204
ncontrol_D1 <- 35728
prevalence_D1 <- rep(c(0.10), times = 3) # prevalence of covid was from literature

r.exposure_D1 <- get_r_from_lor(lor_D1, af_D1, ncase_D1, ncontrol_D1, prevalence_D1, model = "logit",
                                correction = FALSE) 

# calculate r^2 and F-statistic
r2_exp_D1 <- sum(r.exposure_D1^2)
F_D1 <- r.exposure_D1^2 * (data_D1_c$samplesize.exposure - 2) / (1 - r.exposure_D1^2)



# f_stat <- (r2_exp*(n-1-k))/((1-r2_exp)*k)  # where n = samplesize.exposure and k = number of IVs
f_stat_D1 <- (r2_exp_D1*(38000-3-1))/((1-r2_exp_D1)*3)
# R^2 for exposure is
r2_exp_D1  
# F-statistic is
f_stat_D1
