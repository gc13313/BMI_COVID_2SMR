#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()

#setwd
setwd("")


#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#

exposure_dat <-extract_instruments("ieu-b-40", p1=5e-08, r2=0.001)
exposure_dat <- as.data.frame(rbind(exposure_dat))

#---------------------------------------------------------------------#
#                          R2 and F-statistic                         #----
#---------------------------------------------------------------------#
head(exposure_dat)


# Calculate R2 and F stat for exposure_dat
#method 1
exposure_dat$r2 <- (2 * (exposure_dat$beta.exposure^2) * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure)) /
  (2 * (exposure_dat$beta.exposure^2) * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure) +
     2 * exposure_dat$samplesize.exposure * exposure_dat$eaf.exposure * (1 - exposure_dat$eaf.exposure) * exposure_dat$se.exposure^2)

exposure_dat$F <- exposure_dat$r2 * (exposure_dat$samplesize.exposure - 2) / (1 - exposure_dat$r2)


# Calculate R2 for each dataset 
r2_func <- function(id)
{
  x <- exposure_dat[which(exposure_dat$id.exposure==id),]
  sum(x$r2, na.rm = T)
}

variance_bmi <- r2_func("ieu-b-40")


# Calculate F
F_func <- function(id)
{
  x <- exposure_dat[which(exposure_dat$id.exposure==id),]
  sum(x$F, na.rm = T)
}

F_bmi <- F_func("ieu-b-40")



col_order <- c("exposure", "samplesize.exposure", "SNP",
               "effect_allele.exposure", "other_allele.exposure", "r2", "F", "beta.exposure", "se.exposure", "eaf.exposure")
exposure_dat2 <- exposure_dat[, col_order]

exposure_dat2$exposure[exposure_dat2$exposure=="body mass index || id:ieu-b-40"] <- 'BMI'


# Save exposure data

write.xlsx(exposure_dat2, file = "BMI_F_r2.xlsx")
exposure_dat2 <- read.xlsx(xlsxFile = "BMI_F_r2.xlsx")




# Calculate F 
exposure_dat %>%
  group_by(id.exposure) %>%
  dplyr::summarize(F_stat = mean(F, na.rm=TRUE))


#ieu-b-40      72.8

exposure_dat %>%
  group_by(id.exposure) %>%
  dplyr::summarize(F_stat = median(F, na.rm=TRUE))

#id.exposure F_stat
#<chr>        <dbl>
#1 ieu-b-40      50.7

# Calculate r2
exposure_dat %>%
  group_by(id.exposure) %>%
  dplyr::summarize(r2_stat = mean(r2, na.rm=TRUE))

exposure_dat %>%
  group_by(id.exposure) %>%
  dplyr::summarize(r2_stat = median(r2, na.rm=TRUE))


