#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)
library(gtools)
#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#

##LOAD DATA
A1 <- read.xlsx("results_A1_b_PROX.xlsx", rowNames = F)
A2 <- read.xlsx("results_A2_b.xlsx", rowNames = F)
B1 <- read.xlsx("results_B1_b.xlsx", rowNames = F)
B2 <- read.xlsx("results_B2_b.xlsx", rowNames = F)
C1 <- read.xlsx("results_C1_b_PROX.xlsx", rowNames = F)
C2 <- read.xlsx("results_C2_b.xlsx", rowNames = F)
D1 <- read.xlsx("results_D1_b_PROX.xlsx", rowNames = F)

BMI_Yengo <- rbind(A1, A2, B1, B2, C1, C2, D1)
BMI_Yengo$group<-"IVW (unadjusted)"

BMI_Yengo$outcome[BMI_Yengo$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'
BMI_Yengo$outcome[BMI_Yengo$id.outcome=="ebi-a-GCST010778"] <- 'C1 Covid vs lab or self-reported negative'
BMI_Yengo$outcome[BMI_Yengo$id.outcome=="ebi-a-GCST010781"] <- 'D1 Predicted covid vs predicted or self-reported negative'

##LOAD DATA - SMOKING
A1_SMOKING <- read.xlsx("MVMR_SMOKING_A1_b.xlsx", rowNames = T)
A1_SMOKING$outcome <- 'A1 Very severe Covid vs not hospitalised Covid'
A2_SMOKING <- read.xlsx("MVMR_SMOKING_A2_b.xlsx", rowNames = T)
B1_SMOKING <- read.xlsx("MVMR_SMOKING_B1_b.xlsx", rowNames = T)
B2_SMOKING <- read.xlsx("MVMR_SMOKING_B2_b.xlsx", rowNames = T)
C1_SMOKING <- read.xlsx("MVMR_SMOKING_C1_b.xlsx", rowNames = T)
C1_SMOKING$outcome <- 'C1 Covid vs lab or self-reported negative'
C2_SMOKING <- read.xlsx("MVMR_SMOKING_C2_b.xlsx", rowNames = T)
D1_SMOKING <- read.xlsx("MVMR_SMOKING_D1_b.xlsx", rowNames = T)
D1_SMOKING$outcome <- 'D1 Predicted covid vs predicted or self-reported negative'

BMI_SMOKING <- smartbind(A1_SMOKING, A2_SMOKING, B1_SMOKING, B2_SMOKING, C1_SMOKING, C2_SMOKING, D1_SMOKING)
BMI_SMOKING$group<-"IVW (adjusted for smoking)"
BMI_SMOKING<-subset(BMI_SMOKING, exposure=="BMI")

##LOAD DATA - EDUCATION
A1_EDUCATION <- read.xlsx("MVMR_EDUCATION_A1_b.xlsx", rowNames = T)
A1_EDUCATION$outcome <- 'A1 Very severe Covid vs not hospitalised Covid'
A2_EDUCATION <- read.xlsx("MVMR_EDUCATION_A2_b.xlsx", rowNames = T)
B1_EDUCATION <- read.xlsx("MVMR_EDUCATION_B1_b.xlsx", rowNames = T)
B2_EDUCATION <- read.xlsx("MVMR_EDUCATION_B2_b.xlsx", rowNames = T)
C1_EDUCATION <- read.xlsx("MVMR_EDUCATION_C1_b.xlsx", rowNames = T)
C1_EDUCATION$outcome <- 'C1 Covid vs lab or self-reported negative'
C2_EDUCATION <- read.xlsx("MVMR_EDUCATION_C2_b.xlsx", rowNames = T)
D1_EDUCATION <- read.xlsx("MVMR_EDUCATION_D1_b.xlsx", rowNames = T)
D1_EDUCATION$outcome <- 'D1 Predicted covid vs predicted or self-reported negative'

BMI_EDUCATION <- smartbind(A1_EDUCATION, A2_EDUCATION, B1_EDUCATION, B2_EDUCATION, C1_EDUCATION, C2_EDUCATION, D1_EDUCATION)
BMI_EDUCATION$group<-"IVW (adjusted for education)"
BMI_EDUCATION<-subset(BMI_EDUCATION, exposure=="BMI")

##LOAD DATA - INCOME
A1_INCOME <- read.xlsx("MVMR_INCOME_A1_b.xlsx", rowNames = T)
A1_INCOME$outcome <- 'A1 Very severe Covid vs not hospitalised Covid'
A2_INCOME <- read.xlsx("MVMR_INCOME_A2_b.xlsx", rowNames = T)
B1_INCOME <- read.xlsx("MVMR_INCOME_B1_b.xlsx", rowNames = T)
B2_INCOME <- read.xlsx("MVMR_INCOME_B2_b.xlsx", rowNames = T)
C1_INCOME <- read.xlsx("MVMR_INCOME_C1_b.xlsx", rowNames = T)
C1_INCOME$outcome <- 'C1 Covid vs lab or self-reported negative'
C2_INCOME <- read.xlsx("MVMR_INCOME_C2_b.xlsx", rowNames = T)
D1_INCOME <- read.xlsx("MVMR_INCOME_D1_b.xlsx", rowNames = T)
D1_INCOME$outcome <- 'D1 Predicted covid vs predicted or self-reported negative'

BMI_INCOME <- smartbind(A1_INCOME, A2_INCOME, B1_INCOME, B2_INCOME, C1_INCOME, C2_INCOME, D1_INCOME)
BMI_INCOME$group<-"IVW (adjusted for income)"
BMI_INCOME$outcome[BMI_INCOME$id.outcome=="ebi-a-GCST010775"] <- 'A1 Very severe Covid vs not hospitalised Covid'


BMI_INCOME<-subset(BMI_INCOME, exposure=="BMI")

BMI_multi<-smartbind(BMI_SMOKING, BMI_EDUCATION, BMI_INCOME)

MVMR_BMI <- subset(BMI_multi, select = c(outcome, b, se, group))

#specify method
MVMR_BMI$method <- "Multivariable MR"

#univar
UNI_BMI<-subset(BMI_Yengo, method=="Inverse variance weighted")
UNI_BMI$method[UNI_BMI$method=="Inverse variance weighted"] <- 'IVW'
UNI_BMI <- subset(UNI_BMI, select = c(outcome, b, se, group))
UNI_BMI$method <- "Univariable MR"


head(MVMR_BMI)
head(UNI_BMI)

BMI_res<-rbind(UNI_BMI, MVMR_BMI)

results_all<-BMI_res


as.factor(results_all$group)
  results_all$group <- factor(results_all$group, levels = c("IVW (unadjusted)", "IVW (adjusted for smoking)", "IVW (adjusted for education)", "IVW (adjusted for income)"))

results_all <- arrange(results_all, outcome, group)


a <- metagen(TE = b, seTE = se, data = results_all, 
             studlab = paste(group), sm = "OR",
             hakn = FALSE, subgroup = outcome, fixed = FALSE, random=F)


print(a)

#forest plot
forest_results_SA_b<-forest.meta(a, studlab = T, 
                                 type.study="square",
                                 squaresize=0.5,
                                 lty.random = 2,
                                 bylab = " ",
                                 text.random = "Total", # write anything 
                                 text.random.w = "Total",
                                 col.study = c("deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                               "deepskyblue", "goldenrod1", "indianred", "aquamarine4") ,    
                                 col.square = c("deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4",
                                                "deepskyblue", "goldenrod1", "indianred", "aquamarine4") , 
                                 col.diamond="white", 
                                 col.diamond.lines="black",
                                 col.label.right="black",
                                 col.label.left="black", 
                                 colgap.right = "0.5cm",
                                 colgap.forest.left ="0.5cm",
                                 col.by = "black",
                                 xlab="OR per SD increase in BMI", 
                                 leftcols=c("studlab"),# To remove "logHR" and "seHR" from plot
                                 leftlabs = c("Outcome"),
                                 rightcols=c("effect", "ci"),
                                 rightlabs=c("OR","[95% CI]"),
                                 test.overall = F,
                                 lwd=3,
                                 print.I2 = a$comb.fixed,
                                 plotwidth="10.5cm",
                                 print.I2.ci = FALSE, 
                                 print.tau2 = F, 
                                 print.Q = FALSE,
                                 print.subgroup.name=F,
                                 digits.mean = 2,
                                 digits.addcols.right = 3,
                                 fontsize = 12,
                                 overall = FALSE,
                                 overall.hetstat = FALSE,
                                 test.subgroup.fixed=FALSE,
                                 fixed=F,
                                 smlab="")

forest_results_SA_b <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=3200, width=3200)
  print(plot_name)
  dev.off()
}


save_func("forest_results_BMI_covid_MVMR2.png", forest_results_SA_b)

