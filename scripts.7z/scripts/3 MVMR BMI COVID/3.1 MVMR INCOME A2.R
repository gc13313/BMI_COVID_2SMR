rm(list=ls()) #Remove any existing objects in R 
library(data.table)
library(purrr)
library(TwoSampleMR)
library(MRInstruments)
#library(xlsx)
library(readxl)
library(dplyr)
library(ggplot2)
library(ggforestplot)



#install.packages("remotes")
library(remotes)
install_github("WSpiller/MVMR", build_opts = c("--no-resave-data", "--no-manual"), build_vignettes = TRUE)

ao <- available_outcomes()

# Set working directory - folder in my computer
setwd("")
#---------------------------------------------------------------------#
#                        BMI Exposure                            #----
#---------------------------------------------------------------------#

#currently used https://gwas.mrcieu.ac.uk/datasets/ieu-b-25/
bmidat <- extract_instruments("ieu-b-40") #23 gwas significant snps


incomedat <- extract_outcome_data(snps = bmidat$SNP, outcomes = 'ukb-b-7408')

############################################################################
#                                 outcome data                            #
############################################################################
## Extract Covid data: Very severe Covid vs population - release 6
A2 = fread("COVID19_HGI_A2_ALL_leave_23andme_20210607.b37.txt.gz")
outdat <- A2
outdat$outcome <- "A2 Very severe Covid vs population"
outdat<- rename(outdat, c("SNP"="rsid",
                            "chr.outcome"="#CHR", 
                            "effect_allele.outcome"="ALT",
                            "other_allele.outcome"="REF",
                            "beta.outcome"="all_inv_var_meta_beta",
                            "se.outcome"="all_inv_var_meta_sebeta",
                            "pval.outcome"="all_inv_var_meta_p",                              
                            "eaf.outcome" = "all_meta_AF",
                            "SNPid"="SNP",
                            "pval.het"="all_inv_var_het_p"))
outdat$id.outcome <- rep("A2 Very severe Covid vs population", nrow(outdat))

############################################################################
#                                  Run UVMR                                #
############################################################################

uvmr_res <- harmonise_data(bmidat, outdat) %>% 
  mr(., method_list = "mr_ivw") %>%
  mutate(analysis = "IVW (unadjusted)")


############################################################################
#                                  Run MVMR                                #
############################################################################

##
## Harmonise data

# First, orient BMI and income data to the same effect allele
dat1 <- harmonise_data(bmidat, incomedat) %>% 
  rename_at(vars(ends_with("outcome")), ~sub("outcome", "income", .)) %>%
  filter(mr_keep == T)

# Second, orient BMI and outcomes data to the same effect allele
dat2 <- select(bmidat, chr.exposure:exposure) %>%
  harmonise_data(., outdat) %>% 
  select(!ends_with("exposure")) %>%
  filter(mr_keep == T)

# Third, merge data
dat <- merge(dat1, dat2, by = "SNP")


##
## Function for performing MVMR

run_mvmr <- function(out) {
  
  # Filter data for one outcome
  df <- filter(dat, outcome == out)
  
  # Format datasets to MVMR package
  df <- MVMR::format_mvmr(BXGs = df[, c("beta.exposure", "beta.income")],
                          BYG = df[, "beta.outcome"],
                          seBXGs = df[, c("se.exposure", "se.income")],
                          seBYG = df[, "se.outcome"],
                          RSID = df[, "SNP"]
  ) 
  
  # Test for weak instruments (assume no sample overlap between bmi and income datasets)
  weakiv <- MVMR::strength_mvmr(r_input = df, gencov = 0) %>%
    as.data.table(.) %>%
    rename(cF_BMI = exposure1, cF_income = exposure2) %>%
    mutate(outcome = out)
  
  # Test for horizontal pleiotropy (assume no sample overlap between BMI and income datasets)
  pleio <- MVMR::pleiotropy_mvmr(r_input = df, gencov = 0) %>%
    as.data.table(.) %>%
    mutate(outcome = out)
  
  # Run MVMR to estimate direct effects
  eff <- MVMR::ivw_mvmr(r_input = df) %>%
    as.data.table(.) %>%
    mutate(., exposure = c("BMI", "income")) %>%
    mutate(outcome = out)
  
  # Combine MVMR estimates
  res <- merge(weakiv, pleio, by = "outcome") %>%
    merge(., eff, by = "outcome")
  
}				  


##
## Run MVMR to estimate direct effects 

mvmr_res <- map(unique(dat$outcome), ~run_mvmr(.)) %>%
  bind_rows %>%
  mutate(analysis = "IVW (adjusted for income)") %>%
  rename(b = Estimate, se = "Std. Error", pval = "Pr(>|t|)") %>%
  filter(exposure == "BMI")

############################################################################
#                           Combine results                                #
############################################################################


results <- smartbind(uvmr_res, mvmr_res)

write.xlsx(results, "MVMR_INCOME_A2_b.xlsx", row.names= T, overwrite=T)







