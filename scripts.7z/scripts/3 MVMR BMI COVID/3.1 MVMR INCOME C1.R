rm(list=ls()) #Remove any existing objects in R 


library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)

if (!require("pacman")) install.packages("pacman")
pacman::p_load("MRInstruments", "TwoSampleMR", "tidyverse", "dplyr", "ggpubr", "purrr", "remotes", "ggplot2", "ggforce", "data.table", "ggforestplot", "gtools", "openxlsx")
pacman::p_load_gh("Spiller/MVMR")

ao <- available_outcomes()

# Set working directory - folder in my computer
setwd("")
#---------------------------------------------------------------------#
#                        BMI Exposure                            #----
#---------------------------------------------------------------------#

#currently used https://gwas.mrcieu.ac.uk/datasets/ieu-b-25/
bmidat <- extract_instruments("ieu-b-40") #23 gwas significant snps


incomedat <- extract_outcome_data(snps = bmidat$SNP, outcomes = 'ukb-b-7408')

############################################################################
#                                 outcome data                            #
############################################################################
C1 <- extract_outcome_data(snps=incomedat$SNP, outcomes="ebi-a-GCST010778",proxies = T)

outdat<-C1

############################################################################
#                                  Run UVMR                                #
############################################################################

uvmr_res <- harmonise_data(bmidat, outdat) %>% 
  mr(., method_list = "mr_ivw") %>%
  mutate(analysis = "IVW (unadjusted)")


############################################################################
#                                  Run MVMR                                #
############################################################################

##
## Harmonise data

# First, orient BMI and SMOKING data to the same effect allele
dat1 <- harmonise_data(bmidat, incomedat) %>% 
  rename_at(vars(ends_with("outcome")), ~sub("outcome", "income", .)) %>%
  filter(mr_keep == T)

# Second, orient BMI and outcomes data to the same effect allele
dat2 <- select(bmidat, chr.exposure:exposure) %>%
  harmonise_data(., outdat) %>% 
  select(!ends_with("exposure")) %>%
  filter(mr_keep == T)

# Third, merge data
dat <- merge(dat1, dat2, by = "SNP")


##
## Function for performing MVMR

run_mvmr <- function(out) {
  
  # Filter data for one outcome
  df <- filter(dat, outcome == out)
  
  # Format datasets to MVMR package
  df <- MVMR::format_mvmr(BXGs = df[, c("beta.exposure", "beta.income")],
                          BYG = df[, "beta.outcome"],
                          seBXGs = df[, c("se.exposure", "se.income")],
                          seBYG = df[, "se.outcome"],
                          RSID = df[, "SNP"]
  ) 
  
  # Test for weak instruments (assume no sample overlap between bmi and income datasets)
  weakiv <- MVMR::strength_mvmr(r_input = df, gencov = 0) %>%
    as.data.table(.) %>%
    rename(cF_BMI = exposure1, cF_SMOKING = exposure2) %>%
    mutate(outcome = out)
  
  # Test for horizontal pleiotropy (assume no sample overlap between BMI and income datasets)
  pleio <- MVMR::pleiotropy_mvmr(r_input = df, gencov = 0) %>%
    as.data.table(.) %>%
    mutate(outcome = out)
  
  # Run MVMR to estimate direct effects
  eff <- MVMR::ivw_mvmr(r_input = df) %>%
    as.data.table(.) %>%
    mutate(., exposure = c("BMI", "Smoking")) %>%
    mutate(outcome = out)
  
  # Combine MVMR estimates
  res <- merge(weakiv, pleio, by = "outcome") %>%
    merge(., eff, by = "outcome")
  
}				  


##
## Run MVMR to estimate direct effects 

mvmr_res <- map(unique(dat$outcome), ~run_mvmr(.)) %>%
  bind_rows %>%
  mutate(analysis = "IVW (adjusted for income)") %>%
  rename(b = Estimate, se = "Std. Error", pval = "Pr(>|t|)") %>%
  filter(exposure == "BMI")

############################################################################
#                           Combine results                                #
############################################################################


results <- smartbind(uvmr_res, mvmr_res)

write.xlsx(results, "MVMR_INCOME_C1_b.xlsx", row.names= T, overwrite=T)







