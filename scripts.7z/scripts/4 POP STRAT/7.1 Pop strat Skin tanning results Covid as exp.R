#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: covid
# Outcome: skin tanning

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
#setwd
setwd("")

#exposure_dat_A1 <- read.xlsx(xlsxFile = "exposure_dat_A1.xlsx")
exposure_dat_A1 <-extract_instruments("ebi-a-GCST010775", p1 = 5e-06)
exposure_dat_C1 <-extract_instruments("ebi-a-GCST010778", p1 = 5e-06)
exposure_dat_D1 <-extract_instruments("ebi-a-GCST010781", p1 = 5e-06)


exposure_dat_A2 <- read.xlsx(xlsxFile = "exposure_dat_A2.xlsx")
exposure_dat_B1 <- read.xlsx(xlsxFile = "exposure_dat_B1.xlsx")
exposure_dat_B2 <- read.xlsx(xlsxFile = "exposure_dat_B2.xlsx")
exposure_dat_C2 <- read.xlsx(xlsxFile = "exposure_dat_C2.xlsx")

#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#Skin tanning (ordered categorical - treating as continuous) 

tanning_A1 <- extract_outcome_data(snps=exposure_dat_A1$SNP, outcomes="ukb-b-533", proxies=T)
tanning_A2 <- extract_outcome_data(snps=exposure_dat_A2$SNP, outcomes="ukb-b-533", proxies=T)
tanning_B1 <- extract_outcome_data(snps=exposure_dat_B1$SNP, outcomes="ukb-b-533", proxies=T)
tanning_B2 <- extract_outcome_data(snps=exposure_dat_B2$SNP, outcomes="ukb-b-533", proxies=T)
tanning_C1 <- extract_outcome_data(snps=exposure_dat_C1$SNP, outcomes="ukb-b-533", proxies=T)
tanning_C2 <- extract_outcome_data(snps=exposure_dat_C2$SNP, outcomes="ukb-b-533", proxies=T)
tanning_D1 <- extract_outcome_data(snps=exposure_dat_D1$SNP, outcomes="ukb-b-533", proxies=T)

#out_dat_c <- as.data.frame(rbind(tanning))

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_A1_c <- harmonise_data(exposure_dat = exposure_dat_A1, outcome_dat = tanning_A1)
data_A2_c <- harmonise_data(exposure_dat = exposure_dat_A2, outcome_dat = tanning_A2)
data_B1_c <- harmonise_data(exposure_dat = exposure_dat_B1, outcome_dat = tanning_B1)
data_B2_c <- harmonise_data(exposure_dat = exposure_dat_B2, outcome_dat = tanning_B2)
data_C1_c <- harmonise_data(exposure_dat = exposure_dat_C1, outcome_dat = tanning_C1)
data_C2_c <- harmonise_data(exposure_dat = exposure_dat_C2, outcome_dat = tanning_C2)
data_D1_c <- harmonise_data(exposure_dat = exposure_dat_D1, outcome_dat = tanning_D1)

#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#


results_A1_c <- mr(data_A1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_A2_c <- mr(data_A2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B1_c <- mr(data_B1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_B2_c <- mr(data_B2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C1_c <- mr(data_C1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_C2_c <- mr(data_C2_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))
results_D1_c <- mr(data_D1_c, method_list = c("mr_ivw", "mr_egger_regression", "mr_weighted_median"))

results_all_c <- as.data.frame(rbind(results_A1_c, results_A2_c, results_B1_c, results_B2_c, results_C1_c, results_C2_c, results_D1_c))






write.xlsx(results_all_c, file = "popstrat_covid_tanning.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "popstrat_covid_tanning.xlsx")




