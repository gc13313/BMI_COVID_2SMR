#######################################################################
#                            TWO SAMPLE MR                            #
#######################################################################
# R version 4.0.2 

# Exposure: BMI
# Outcome: skin tanning

#---------------------------------------------------------------------#
#                            Housekeeping                             #
#---------------------------------------------------------------------#
rm(list=ls()) #Remove any existing objects in R 

library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(dplyr)
ao <- available_outcomes()

#---------------------------------------------------------------------#
#                           Exposure                                  #
#---------------------------------------------------------------------#
#BMI - yengo ieu-b-40
exposure_dat_locke <- extract_instruments("ieu-a-2")
exposure_dat_yengo <- extract_instruments("ieu-b-40")

#---------------------------------------------------------------------#
#                          Combine exposures                          #
#---------------------------------------------------------------------#

exposure_dat <- as.data.frame(rbind(exposure_dat_locke, exposure_dat_yengo))

#---------------------------------------------------------------------#
#                           Outcome                                   #
#---------------------------------------------------------------------#
#Skin tanning (ordered categorical - guess I'm treating as continuous) 

tanning <- extract_outcome_data(snps=exposure_dat$SNP, outcomes="ukb-b-533",proxies = F)

out_dat_c <- as.data.frame(rbind(tanning))

#---------------------------------------------------------------------#
#                           Harmonise                                 #----
#---------------------------------------------------------------------#

data_all_c <- harmonise_data(
  exposure_dat = exposure_dat, 
  outcome_dat = out_dat_c
)

#---------------------------------------------------------------------#
#                           MR Analyses                               #----
#---------------------------------------------------------------------#

#The default is list(test_dist = "z", nboot = 1000, Cov = 0, penk = 20, phi = 1, alpha = 0.05, Qthresh = 0.05, over.dispersion = TRUE, loss.function = "huber")
mr_method_list()

results_all_c <- mr(data_all_c, method_list = c("mr_ivw", "mr_egger_regression", 
                                                "mr_weighted_median"))

#setwd
setwd("")

write.xlsx(results_all_c, file = "results_all_c_ps_bmi_skin.xlsx", overwrite=T)
results_all_c <- read.xlsx(xlsxFile = "results_all_c_ps_bmi_skin.xlsx")


