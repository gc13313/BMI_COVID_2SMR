#---------------------------------------------------------------------#
#                            Housekeeping                             #----
#---------------------------------------------------------------------#

# Clear environment
rm(list=ls()) #Remove any existing objects in R 
library(devtools)
#devtools::install_github("MRCIEU/TwoSampleMR")
library(TwoSampleMR)
library(MRInstruments)
library(purrr)
library(openxlsx)
library(meta)
library(metafor)
library(cowplot)
library(gridGraphics)
library(ggpubr)
library(dplyr)
library(tidyverse)
library(readxl)
library(data.table)
library(ggforestplot)

#---------------------------------------------------------------------#
#                             data prep                               #----
#---------------------------------------------------------------------#
#setwd
setwd("")

##LOAD DATA
results_all_c <- read.xlsx(xlsxFile = "results_all_c_ps_bmi_skin.xlsx")
results_all_ivw<-subset(results_all_c, method!="Weighted mode")
results_all_ivw<-subset(results_all_ivw, method!="Maximum likelihood")
results_all_ivw<-subset(results_all_ivw, method!="Unweighted regression")


results_all_ivw$method[results_all_ivw$method=="Inverse variance weighted"] <- 'IVW'

results_all_ivw$exposure[results_all_ivw$exposure=="Body mass index || id:ieu-a-2"] <- 'BMI: Excluding UKB'
results_all_ivw$exposure[results_all_ivw$exposure=="body mass index || id:ieu-b-40"] <- 'BMI: Including UKB'


results_all_ivw$outcome[results_all_ivw$outcome=="Ease of skin tanning || id:ukb-b-533"] <- 'Ease of skin tanning'

a <- metagen(TE = b, seTE = se, data = results_all_ivw, 
             studlab = paste(method), sm = "MD",
             hakn = FALSE, byvar = exposure, comb.fixed = FALSE, comb.random=F)


print(a)

#forest plot
forest_results_c <-forest.meta(a, studlab = T, 
                               type.study="square",
                               squaresize=0.5,
                               lty.random = 2,
                               bylab = " ",
                               text.random = "Total", # write anything 
                               text.random.w = "Total",
                               col.study = c("deepskyblue", "goldenrod1", "indianred",
                                             "deepskyblue", "goldenrod1", "indianred") ,    
                               col.square = c("deepskyblue", "goldenrod1", "indianred",
                                              "deepskyblue", "goldenrod1", "indianred") , 
                               col.diamond="white", 
                               col.diamond.lines="black",
                               col.label.right="black",
                               col.label.left="black", 
                               colgap.right = "0.5cm",
                               colgap.forest.left ="0.5cm",
                               col.by = "black",
                               xlab="Difference in mean of ease of skin tanning", 
                               leftcols=c("studlab", "nsnp"),# To remove "logHR" and "seHR" from plot
                               leftlabs = c("Outcome", "SNPs"),
                               rightcols=c("effect", "ci"),
                               rightlabs=c("MD","[95% CI]"),
                               test.overall = F,
                               lwd=3,
                               print.I2 = a$comb.fixed,
                               plotwidth="10.5cm",
                               print.I2.ci = FALSE, 
                               print.tau2 = F, 
                               print.Q = FALSE,
                               print.subgroup.name=F,
                               digits.mean = 3,
                               digits=3,
                               digits.addcols.right = 3,
                               fontsize = 12,
                               overall = FALSE,
                               overall.hetstat = FALSE,
                               test.subgroup.fixed=FALSE,
                               fixed=F,
                               smlab="")
forest_results_c <- recordPlot()

#save
save_func <- function(file_name, plot_name)
{
  png(file_name, res=300, height=3000, width=2600)
  print(plot_name)
  dev.off()
}


save_func("forest_bmi_tanning_S5a.png", forest_results_c)






